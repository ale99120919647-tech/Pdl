PDL - PROYECTO ANDROID

IMPORTANTE: este ZIP contiene el proyecto fuente, NO el APK ya compilado.
Se puede generar el APK usando GitHub Actions desde el navegador del teléfono, sin PC.

PASOS (necesitas una cuenta gratuita de GitHub y conexión a Internet):
1. Entra en https://github.com desde el navegador del teléfono e inicia sesión.
2. Crea un repositorio nuevo, por ejemplo: PDL-Android. Puedes dejarlo privado.
3. Sube los archivos y carpetas que están DENTRO de la carpeta PDL_Android, incluida la carpeta oculta .github.
   IMPORTANTE: debe quedar .github/workflows/crear-apk.yml en la raíz del repositorio.
4. Abre la pestaña Actions del repositorio. Si GitHub pide habilitar Actions, acéptalo.
5. En el flujo “Crear APK de PDL”, pulsa “Run workflow” y después el botón verde para ejecutarlo.
   Si subiste todos los archivos a la rama main/master, también puede iniciarse automáticamente.
6. Espera a que termine con una marca verde. Abre esa ejecución y busca “Artifacts”.
7. Descarga el archivo “PDL-APK.zip” en el teléfono y descomprímelo. Dentro estará app-debug.apk.
8. Toca app-debug.apk para instalarlo. Android puede pedir autorización para instalar aplicaciones desde el navegador o gestor de archivos; habilítala solo para esa aplicación y continúa si confías en el archivo que generaste.

Si falla la compilación, abre la ejecución en Actions y comparte el texto del error para poder corregirlo.

Los datos de esta primera versión se guardan localmente en el teléfono. No desinstales ni borres los datos de la aplicación sin hacer antes una copia de seguridad.
